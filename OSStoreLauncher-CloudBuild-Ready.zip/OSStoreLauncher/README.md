# OS Store Android Launcher

A starter Android launcher app. It can be selected as the Android Home app and displays installed launchable apps.

## Build without Android Studio

This repository includes a GitHub Actions workflow at `.github/workflows/build.yml`.

1. Create a GitHub repository.
2. Upload the **contents** of this folder, keeping the `.github` folder and its workflow.
3. Open the repository's **Actions** tab.
4. Select **Build OS Store APK** and press **Run workflow** (or push to `main`).
5. Open the completed workflow run and download the `OSStore-debug-apk` artifact.
6. Extract the artifact ZIP and install `app-debug.apk` on your Android device.

## Notes

- This is a starter launcher, not a complete operating system.
- Android controls default launcher selection. The app requests the Home role using Android's system prompt.
- The app lists apps that expose a standard launcher activity.
