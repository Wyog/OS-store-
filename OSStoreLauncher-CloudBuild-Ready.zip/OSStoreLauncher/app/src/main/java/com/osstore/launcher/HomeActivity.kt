package com.osstore.launcher

import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class HomeActivity : Activity() {
    private val bg = Color.rgb(12, 12, 16)
    private val panel = Color.rgb(29, 29, 37)
    private val accent = Color.rgb(255, 65, 75)
    private lateinit var appsGrid: GridLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    override fun onResume() {
        super.onResume()
        if (::appsGrid.isInitialized) loadApps()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(16))
            setBackgroundColor(bg)
        }

        val title = TextView(this).apply {
            text = "OS STORE"
            textSize = 27f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        }
        page.addView(title)

        val subtitle = TextView(this).apply {
            text = "Your home. Your OS."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(4), 0, dp(18))
        }
        page.addView(subtitle)

        val setDefault = Button(this).apply {
            text = "Set as default launcher"
            setTextColor(Color.WHITE)
            background = rounded(accent, 16)
            setOnClickListener { requestDefaultHome() }
        }
        page.addView(setDefault, LinearLayout.LayoutParams(-1, dp(52)))

        val heading = TextView(this).apply {
            text = "YOUR APPS"
            textSize = 13f
            setTextColor(accent)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(24), 0, dp(12))
        }
        page.addView(heading)

        val scroll = ScrollView(this)
        appsGrid = GridLayout(this).apply {
            columnCount = 4
            useDefaultMargins = true
        }
        scroll.addView(appsGrid)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = TextView(this).apply {
            text = "OS Store Launcher • Starter edition"
            textSize = 11f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, 0)
        }
        page.addView(footer)
        setContentView(page)
        loadApps()
    }

    private fun loadApps() {
        appsGrid.removeAllViews()
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val activities = packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }

        for (info in activities) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(5), dp(10), dp(5), dp(10))
                background = rounded(panel, 14)
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    val launch = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
                    if (launch != null) startActivity(launch)
                    else Toast.makeText(this@HomeActivity, "Can't open this app", Toast.LENGTH_SHORT).show()
                }
            }
            val icon = TextView(this).apply {
                text = "●"
                textSize = 24f
                setTextColor(accent)
                gravity = Gravity.CENTER
                info.loadIcon(packageManager).let { drawable ->
                    // Use the real installed app icon.
                    val size = dp(42)
                    drawable.setBounds(0, 0, size, size)
                    setCompoundDrawables(null, drawable, null, null)
                    compoundDrawablePadding = dp(4)
                    text = ""
                }
            }
            item.addView(icon, LinearLayout.LayoutParams(-1, dp(48)))
            val label = TextView(this).apply {
                text = info.loadLabel(packageManager).toString()
                textSize = 10f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                maxLines = 2
            }
            item.addView(label, LinearLayout.LayoutParams(-1, dp(34)))
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(94)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(3), dp(3), dp(3), dp(3))
            }
            appsGrid.addView(item, params)
        }

        if (activities.isEmpty()) {
            val empty = TextView(this).apply {
                text = "No launchable apps found."
                setTextColor(Color.LTGRAY)
                textSize = 14f
            }
            appsGrid.addView(empty)
        }
    }

    private fun requestDefaultHome() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager.isRoleAvailable(RoleManager.ROLE_HOME) &&
                !roleManager.isRoleHeld(RoleManager.ROLE_HOME)) {
                startActivityForResult(roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME), 100)
            } else {
                Toast.makeText(this, "OS Store is already the default launcher", Toast.LENGTH_LONG).show()
            }
        } else {
            val chooser = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            startActivity(chooser)
        }
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
